import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from tkinter import ttk
import db_config
from tkcalendar import DateEntry
import pymysql
from tkinter import messagebox
import pandas as pd
import matplotlib.pyplot as plt
import winsound
from playsound import playsound
import win32api, win32con



con = pymysql.connect(host=db_config.DB_SERVER,
                          user=db_config.DB_USER,
                          password=db_config.DB_PASS,
                          database=db_config.DB)

cursor = con.cursor()

SQL_Query = pd.read_sql_query(
    '''select
    MalariaID,
    DATEVISIT,
    GENDER
    from MalariaApp''', con)



df3 = pd.DataFrame(SQL_Query , columns=['MalariaID', 'DATEVISIT'])


root = tk.Tk()
root.config(bg="grey")
fm=tk.Frame(root,bg="grey",width=500,height=300)
fm.pack(side=tk.LEFT,fill=tk.BOTH)
fmbar2=tk.Frame(root,bg="white",width=500,height=380)
fmbar2.pack(side=tk.RIGHT, fill=tk.BOTH)

search_text_var = tk.StringVar()
studmatricno=tk.StringVar()
studname=tk.StringVar()
studaddress=tk.StringVar()
studnextofkin=tk.StringVar()
studnextofkinmobile=tk.StringVar()
v = tk.StringVar()
v.set(0)
studmobile=tk.StringVar()
daignosis=tk.StringVar()
studvisit= tk.StringVar()

def database():

    con = pymysql.connect(host=db_config.DB_SERVER,
                          user=db_config.DB_USER,
                          password=db_config.DB_PASS,
                          database=db_config.DB)
    a=studmatricno.get()
    b=studname.get()
    c=studaddress.get()
    d=studnextofkin.get()
    e=studnextofkinmobile.get()
    f=v.get()
    g=studmobile.get()
    h=daignosis.get()
    i=studvisit.get()
    global items
    frequency = 5000  # change it based on sensor input
    duration = 20

    sql="INSERT INTO MalariaApp (MATRICNO,NAME,ADDRESS,NEXTKIN,NXTNO,GENDER,STUDMOBILE,DIAGNOSIS,DATEVISIT) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    vals= (a, b, c, d, e, f, g, h, i)
    cursor = con.cursor()
    cursor.execute(sql, vals)
    cursor.execute("SELECT count(MalariaID) FROM MalariaApp")
    items = cursor.fetchall()
    while items >=((12,),):
        winsound.Beep(frequency, duration)
        win32api.MessageBox(0, "Malaria too high thredshore", "Reminder", win32con.MB_ICONWARNING)
        playsound('7b56d16870b9417ce8af46ead3497a6ad5998a6a8a398619237df806506c6b31.mp3')
        winsound.PlaySound("7b56d16870b9417ce8af46ead3497a6ad5998a6a8a398619237df806506c6b31.mp3",winsound.SND_NODEFAULT| winsound.SND_ASYNC )
        root.destroy()
    else:
     print(items)
    con.commit()
    cursor.close()
    con.close()
    messagebox.showinfo("Database", "Record Added to Database")

def update_records():
    global  row
    global result

    con = pymysql.connect(host=db_config.DB_SERVER,
                          user=db_config.DB_USER,
                          password=db_config.DB_PASS,
                          database=db_config.DB)
    cursor = con.cursor()

    # declaring the variables to update
    var1 = studmatricno.get()  # updated name
    var2 = studname.get()  # updated school
    var3 = studaddress.get()  # updated grade
    var4 = studnextofkin.get()  # updated checkoutdate
    var5 = studnextofkinmobile.get()  # updated bookcode
    var6 = v.get()  # updated ebookname
    var7 = studmobile.get()
    var8 = daignosis.get() # updated school
    var9 = studvisit.get() # updated grade

    query = "UPDATE MalariaApp SET MATRICNO=%s,NAME=%s,ADDRESS=%s,NEXTKIN=%s,NXTNO=%s,GENDER=%s,STUDMOBILE=%s,DIAGNOSIS=%s,DATEVISIT=%s WHERE MATRICNO=%s "
    cursor.execute(query,(var1,var2,var3,var4,var5,var6,var7,var8,var9,search_family.get(),))
    tk.messagebox.showinfo("Updated", "Successfully Updated.")
    con.commit()

def delete_records():
    con = pymysql.connect(host=db_config.DB_SERVER,
                          user=db_config.DB_USER,
                          password=db_config.DB_PASS,
                          database=db_config.DB)

    if(search_family.get()):
        tk.messagebox.showinfo("Deleted", "Successfully Deleted.")
    else:
         con = pymysql.connect(host=db_config.DB_SERVER,
                          user=db_config.DB_USER,
                          password=db_config.DB_PASS,
                          database=db_config.DB)


    cursor = con.cursor()
    cursor.execute("Delete from MalariaApp WHERE MATRICNO='"+ search_family.get() +"'")
    con.commit()
    entry15.delete(0,'end')
    entry_1.delete(0,'end')
    entry_2.delete(0,'end')
    entry_10.delete(0,'end')
    entry_11.delete(0,'end')
    entry_5.delete(0, 'end')
    v.set(0)
    daignosis.set(0)
    studvisit.delete(0, tk.END)


def search_records():
    global  row
    global result

    con = pymysql.connect(host=db_config.DB_SERVER,
                          user=db_config.DB_USER,
                          password=db_config.DB_PASS,
                          database=db_config.DB)

    vals = search_text_var.get()
    sql = "SELECT * FROM MalariaApp WHERE MATRICNO=%s"
    cursor = con.cursor()
    Lenmem=(vals,)
    result=cursor.execute(sql, Lenmem)
    result = cursor.fetchall()

    if  result:

        for row in result:
            studmatricno.set(result[0][1])
            studname.set(result[0][2])
            studaddress.set(result[0][3])
            studnextofkin.set(result[0][4])
            studnextofkinmobile.set(result[0][5])
            v.set(result[0][6])
            studmobile.set(result[0][7])
            daignosis.set(result[0][8])
            studvisit.focus_set()
        cursor.close()
        con.close()
        print(result)

def VIEWRECORDS():

        con = pymysql.connect(host=db_config.DB_SERVER,
                              user=db_config.DB_USER,
                              password=db_config.DB_PASS,
                              database=db_config.DB)

        cursor = con.cursor()
        win2 = tk.Toplevel()
        message = "Students Report"
        tk.Label(win2, text=message).pack(padx=0, pady=0)
        element_header = ['1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th']
        treeScroll = tk.Scrollbar(win2)
        treeScroll.pack(side='bottom', padx=0, pady=0)
        tree = ttk.Treeview(win2, columns=element_header, show="headings", yscrollcommand=treeScroll)
        tree.column('1st', width=80, minwidth=50, stretch=tk.NO)
        tree.column('2nd', width=80, minwidth=50, stretch=tk.NO)
        tree.column('3rd', width=80, minwidth=50, stretch=tk.NO)
        tree.column('4th', width=50, minwidth=50, stretch=tk.NO)
        tree.column('5th', width=80, minwidth=50, stretch=tk.NO)
        tree.column('6th', width=80, minwidth=50, stretch=tk.NO)
        tree.column('7th', width=80, minwidth=50, stretch=tk.NO)
        tree.column('8th', width=80, minwidth=50, stretch=tk.NO)
        tree.column('9th', width=80, minwidth=50, stretch=tk.NO)


        sqlch = "SELECT * FROM MalariaApp"
        cursor.execute(sqlch, )
        tree.delete(*tree.get_children())
        fetch = cursor.fetchall()
        for data in fetch:
            tree.insert('', 'end', values=(
                data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9]))
        tree.heading("1st", text="MATRICNO")
        tree.heading("2nd", text="NAME")
        tree.heading("3rd", text="ADDRESS")
        tree.heading("4th", text="NEXTKIN")
        tree.heading("5th", text="NXTNO")
        tree.heading("6th", text="GENDER")
        tree.heading("7th", text="STUDMOBILE")
        tree.heading("8th", text="DIAGNOSIS")
        tree.heading("9th", text="DATEVISIT")
        tree.pack(side='left', padx=0, pady=0)
        treeScroll.config(command=tree.yview)

label_0 = tk.Label(fm, text="Malaria Tracking App", width=25, font=("bold", 20))
label_0.place(x=9, y=0)
name =tk.Label(fm, text="SEARCH STUDENT ID-NO", font=('bold',10))
name.place(x=9, y=45)
search_family = tk.Entry(fm,textvariable=search_text_var,font=('bold', 13),width=10)
search_family.place(x=175, y=45)
label_15=tk.Label(fm, text="MATRIC_NO", anchor="w",width=20, font=('bold', 11))
label_15.place(x=9, y=80)
entry15=tk.Entry(fm, textvar=studmatricno,font=('bold', 12), width=20)
entry15.place(x=200, y=80)
label_1 =tk.Label(fm, text="NAME:", width=20,anchor="w",font=('bold', 11))
label_1. place(x=9, y=110)
entry_1 =tk.Entry(fm, textvar=studname,font=('bold', 12), width=20)
entry_1.place(x=200, y=110)
label_2 =tk.Label(fm, text="ADDRESS:", anchor="w",width=20, font=('bold', 11))
label_2.place(x=9, y=140)
entry_2 = tk.Entry(fm, textvar=studaddress, font=('bold', 12), width=20)
entry_2.place(x=200, y=140)
label_10 =tk.Label(fm, text="NEXT OF KIN:", anchor="w",width=20, font=('bold', 11))
label_10.place(x=9, y=170)
entry_10 =tk.Entry(fm, textvar=studnextofkin,font=('bold', 12),width=20)
entry_10.place(x=200, y=170)
label_11=tk.Label(fm, text="NEXT OF KIN MOBILE NUM:", anchor="w",width=20, font=('bold', 11))
label_11.place(x=9, y=200)
entry_11 =tk.Entry(fm, textvar=studnextofkinmobile, font=('bold', 12), width=20)
entry_11.place(x=200, y=200)
label_4 =tk.Label(fm, text="SEX", anchor="w",width=20, font=('bold', 11))
label_4.place(x=9, y=230)
r1 = tk.Radiobutton(root, text='Male!!', value='M', variable=v).place(x=200, y=230)
r1 = tk.Radiobutton(root, text='Female', value='F', variable=v).place(x=260, y=230)
label_5 = tk.Label(fm, text="MOBILE NUMBER:", anchor="w",width=20, font=('bold', 11))
label_5.place(x=9, y=260)
entry_5 = tk.Entry(fm, textvar=studmobile, font=('bold', 12), width=20)
entry_5.place(x=200, y=260)
label_6 =tk.Label(fm, text="DIAGNOSIS:", anchor="w",width=20, font=('bold', 11))
label_6.place(x=9, y=290)
daignosis.set("SELECT") # default value
droplistprog=tk.OptionMenu(fm, daignosis, "MALARIA", "OTHERS")
droplistprog.place(x=200, y=290)
label_7 =tk.Label(fm, text="DATE OF VISIT:", anchor="w",width=20, font=('bold', 11))
label_7.place(x=9, y=320)
#entry_8 = tk.Entry(fm, textvar=studvisit, font=('bold', 12), width=20)
#entry_8.place(x=200, y=320)
studvisit= DateEntry(fm,width=27, year=2019, month=6, day=22,
background='darkblue', foreground='white', borderwidth=14)
studvisit.place(x=200, y=320)
fm.bind(studvisit)

# file = open("jojo.txt", "w")
# file.write( f + "," + i)

tk.Button(fm, text='SUBMIT', width=7, bg='BLACK', fg='WHITE',bd=2,command=database, font=("Arial", 11)).place(x=9, y=350)
tk.Button(fm, text='UPDATE', width=7, bg='BLACK', fg='WHITE',bd=2,command=update_records, font=("Arial", 11)).place(x=85, y=350)
tk.Button(fm, text='DELETE', width=7, bg='BLACK', fg='WHITE', bd=2, command=delete_records,font=("Arial", 11)).place(x=161, y=350)
tk.Button(fm, text='SEARCH', width=7, bg='BLACK', fg='WHITE',bd=2,command=search_records, font=("Arial", 11)).place(x=235, y=350)
tk.Button(fm, text='VIEW-RECORDS', width=15, bg='BLACK', fg='WHITE',bd=2,command=VIEWRECORDS, font=("Arial", 11)).place(x=310, y=350)



cursor = con.cursor()

SQL_Query = pd.read_sql_query(
    '''select
       *
    from MalariaApp''', con)

df = pd.DataFrame(SQL_Query, columns=['MATRICNO','NAME','ADDRESS','NEXTKIN','NXTNO','GENDER','STUDMOBILE','DIAGNOSIS','DATEVISIT'])
figure2 = plt.Figure(figsize=(5, 4), dpi=100)
ax2 = figure2.add_subplot(111)
line2 = FigureCanvasTkAgg(figure2, fmbar2)
line2.get_tk_widget().pack(side=tk.RIGHT, fill=tk.BOTH)
#df.set_index("GENDER",inplace=True)
yer=df.groupby('GENDER')['GENDER'].size()
yer.plot(kind="pie",autopct='%1.1f%%',shadow=True,ax=ax2, startangle=90, fontsize=15)
ax2.set_title("Percentages of Female and Male Infected with Malaria")
print(yer)
print(df)
plt.gcf().canvas.draw_idle()


root.update()
root.mainloop()