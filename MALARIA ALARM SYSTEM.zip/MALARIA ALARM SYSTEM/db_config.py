DB_SERVER = "localhost"
DB_USER = "root"
DB_PASS=""
DB = "school"




